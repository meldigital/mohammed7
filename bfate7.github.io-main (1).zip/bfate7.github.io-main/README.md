# **Porfolio V1**

created with [React](https://reactjs.org/) & [tailwindcss](https://tailwindcss.com/)

Design Inspired from [brittanychiang.com](https://brittanychiang.com/)

### :bell: Please note that this repo contains only the build version

###


&nbsp;
![previw](./preview/preview.png)
